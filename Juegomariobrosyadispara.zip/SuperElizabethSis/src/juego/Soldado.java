package juego;

import java.awt.Color;
import java.awt.Image;
import entorno.Entorno;
import entorno.Herramientas;



public class Soldado {
	double x;
	double y;
	double ancho;
	double alto;
	double angulo;
	Image img;
	
	double pi = Math.PI;
	int signo = -1;
	
	Soldado(double x,double y,double ancho,double alto,double angulo){
	    this.x=x;
		this.y=y;
		this.ancho=ancho;
		this.alto=alto;
		this.angulo=angulo;
		this.img =  Herramientas.cargarImagen("soldado.png");
	}
	
	public void dibujarse(Entorno entorno) {
		entorno.dibujarImagen(img, x, y, 0);
	}
	
	public void mover() {
		//con angulo indico el sentido del movimiento con 0 a la izq y 180 a la der
		
		this.x += Math.cos(pi)*2;
		//this.y += Math.sin(this.angulo)*2;
		
		if (this.x > 1600) {
			this.x=950;
			pi = pi + Math.PI*signo;
			signo = signo*-1;
		}
		if (this.x < -50) {
			this.x=950;
		}	
		
	}
	
	public boolean rebote(Obstaculo obstaculo) {
		if(( x ==obstaculo.x-obstaculo.ancho/2) ||( x == obstaculo.x+obstaculo.ancho/2) || (y == obstaculo.y-obstaculo.alto/2)|| (y == obstaculo.y+obstaculo.alto/2)) {
			pi = pi + Math.PI*signo;
			signo = signo*-1;
			
			return true;
		}
		else {
			return false;
		}
	
	}	
	
	public boolean rebote(Soldado soldado,Soldado soldado1) {
		if(( soldado.x ==soldado1.x-soldado1.ancho/2) ||( soldado.x == soldado1.x+soldado1.ancho/2) || (soldado.y == soldado1.y-soldado1.alto/2)|| (soldado.y == soldado1.y+soldado1.alto/2)) {
			pi = pi + Math.PI*signo;
			signo = signo*-1;
			
			return true;
		}
		else {
			return false;
		}
	
	}	
	
	
	public boolean tocaPrincesa(Princesa princesa) {
		if(( x >princesa.x-princesa.ancho/2) &&( x < princesa.x+princesa.ancho/2) && (y > princesa.y-princesa.alto/2)&& (y < princesa.y+princesa.alto/2)) {
			return true;
		}
		else {
			return false;
		}
	
	}
	
	}
	
	


